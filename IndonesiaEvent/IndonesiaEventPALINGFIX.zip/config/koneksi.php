<?php

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$database = "indonesiaevent";

	$conn = mysqli_connect($hostname,$username,$password,$database);

?>