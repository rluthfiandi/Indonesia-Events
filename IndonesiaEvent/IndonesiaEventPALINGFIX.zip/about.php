<div class="col-md-12">
	<div class="col-md-1">
		
	</div>

	<div class="col-md-10">
		<br><br><br>
		<h3>
			Tentang Kami
		</h3>
		<br>
		<p>
			 Indonesia Events adalah web penyedia info-info event yang berada di Indonesia
		</p>
		
		<p>
			Disini kalian bisa membeli tiket-tiket event
		</p>
		<br><br><br>
		<h3>
			Visi dan Misi
		</h3>
		<br>
		Visi
		<p>
			Menjadi Penyedia Tiket Event terbesar di Indonesia.
		</p>
		<br><br>
		Misi
		<p>
			1.	Menyediakan info-info event di Indonesia.
			<br>
			2.	Menjadi mitra yang bisa dipercara oleh masyarakat, khususnya penyedia tiket event.
			

		</p>

		
	</div>

	<div class="col-md-1">
		
	</div>
</div>